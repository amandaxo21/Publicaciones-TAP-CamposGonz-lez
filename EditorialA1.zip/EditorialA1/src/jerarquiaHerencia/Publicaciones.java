/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jerarquiaHerencia;

/**
 *
 * @author tupik
 */
public class Publicaciones {
    private String titulo;
    private double precio;
    private int noPag;

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    public int getNoPag() {
        return noPag;
    }

    public void setNoPag(int noPag) {
        this.noPag = noPag;
    }
    
    
}
