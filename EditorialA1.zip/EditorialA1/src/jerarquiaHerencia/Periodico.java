package jerarquiaHerencia;

public class Periodico extends Publicaciones implements Periodicidad{
    private String editor;

    public String getEditor() {
        return editor;
    }

    public void setEditor(String editor) {
        this.editor = editor;
    }
    
}
