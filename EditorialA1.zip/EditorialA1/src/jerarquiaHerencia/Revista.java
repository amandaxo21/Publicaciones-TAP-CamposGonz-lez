package jerarquiaHerencia;

public class Revista extends Publicaciones implements Periodicidad{
    private String ISSN;
    private int numero;

    public String getISSN() {
        return ISSN;
    }

    public void setISSN(String ISSN) {
        this.ISSN = ISSN;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }
    
}
