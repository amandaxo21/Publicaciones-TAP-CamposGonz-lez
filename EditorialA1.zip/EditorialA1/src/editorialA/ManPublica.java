package editorialA;
import java.util.ArrayList;
import java.util.Iterator;
import jerarquiaHerencia.*;
public class ManPublica {
    static ArrayList<Publicaciones> ArrPublica = new ArrayList<Publicaciones>();
    private Libro objLibro;
    private Publicaciones objPublica;
    
    public ManPublica(String tit, double precio, int np){
        objPublica = new Publicaciones();
        objPublica.setTitulo(tit);
        objPublica.setPrecio(precio);
        objPublica.setNoPag(np);
    }
    
    public void alta(String ISBN, String Autor, String edicion){
        objLibro = new Libro();
        objLibro.setTitulo(objPublica.getTitulo());
        objLibro.setPrecio(objPublica.getPrecio());
        objLibro.setNoPag(objPublica.getNoPag());
        objLibro.setAutor(Autor);
        objLibro.setEdicion(edicion);
        ArrPublica.add(objLibro);
    }
    
    public void desplegar(){
        System.out.println("....OBJETOS EN LA PUBLICACIÓN....");
        Iterator<Publicaciones> itrPublica = ArrPublica.iterator();
        while(itrPublica.hasNext()){
            Publicaciones publica = itrPublica.next();
            if(publica instanceof Libro){
                Libro book = new Libro();
                book = (Libro)publica;
                System.out.println("ISBN: " + book.getISBN());
                System.out.println("Título: " + book.getTitulo());
            }
        }
    }
}
